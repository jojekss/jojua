package com.example.myapplication

enum class intArray {

}
